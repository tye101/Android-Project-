package com.example.admin_log;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btn_admin, btn_student, btn_instructor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_admin= (Button) findViewById(R.id.Admin);
        btn_student= (Button) findViewById(R.id.Student);
        btn_instructor= (Button) findViewById(R.id.Instructor);
        btn_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLogin();
            }
        });
        btn_student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLoginInstructor();
            }
        });
        btn_instructor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLogin();
            }
        });
    }

    private void openLogin() {
        Intent firstIntent=new Intent(this, Login.class);
        startActivity(firstIntent);
    }
    private void openLoginInstructor() {
        Intent firstIntent=new Intent(this, Login.class);
        startActivity(firstIntent);
    }
}