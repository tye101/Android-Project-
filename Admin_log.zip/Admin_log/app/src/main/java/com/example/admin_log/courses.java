package com.example.admin_log;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.HashMap;

public class courses extends AppCompatActivity {

    Button b1,b2,b3;
    private MyCoursesDb db;
    HashMap<String,String>courses;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);
        db=new MyCoursesDb(this);
        courses=new HashMap<>();

        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCreate1();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCreate();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCreate2();
            }
        });
    }

    public void openActivityCreate(){
        Intent intent = new Intent(this, Edit.class);
        startActivity(intent);
    }
    public void openActivityCreate1(){
        Intent intent = new Intent(this, Create.class);
        startActivity(intent);
    }
    public void openActivityCreate2(){
        Intent intent = new Intent(this, Delete.class);
        startActivity(intent);
    }

}