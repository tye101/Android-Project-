package com.example.admin_log;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.HashMap;
public class Login extends AppCompatActivity {
    EditText ID,Password;
    Button logIn,SignUp;
    MyDBHandler db;
    HashMap<String,String> account;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ID=findViewById(R.id.user);
        Password=findViewById(R.id.pass);
        logIn = findViewById(R.id.log);
        SignUp=findViewById(R.id.signup);
        db= new MyDBHandler(this);
        db.addAccount(new Account("admin","admin123"));


        SignUp.setOnClickListener(view -> {
            db.addAccount(new Account(ID.getText().toString(),Password.getText().toString()));
            ID.setText("");
            Password.setText("");
        });

        logIn.setOnClickListener(view -> {
            String username= ID.getText().toString();
            String password= Password.getText().toString();
            account=db.getUserInfo();
            if(account.get(username).equals(password)){
                Toast.makeText(Login.this,"Welcome",Toast.LENGTH_SHORT).show();
                openActivityCreate();
            }else{
                Toast.makeText(Login.this,"Error Logging In!",Toast.LENGTH_SHORT).show();

            }
        });

    }
    public void openActivityCreate(){
        Intent intent = new Intent(this, courses.class);
        startActivity(intent);
    }
}

