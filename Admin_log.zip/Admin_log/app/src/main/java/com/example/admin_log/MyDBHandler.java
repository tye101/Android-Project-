package com.example.admin_log;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHandler extends SQLiteOpenHelper {
    private static final String TABLE_NAME="Account";
    private static final String COLUMN_ID="ID";
    private static final String COLUMN_ACCOUNT_USERNAME="username";
    private static final String COLUMN_ACCOUNT_PASSWORD="password";
    private static final String DATABASE_NAME = "accounts.db";
    private static final int DATABASE_VERSION =1 ;


    public MyDBHandler(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String create_table_cmd="CREATE TABLE " + TABLE_NAME +
                "(" + COLUMN_ID + "INTEGER PRIMARY KEY, " +
                COLUMN_ACCOUNT_USERNAME + " TEXT, " +
                COLUMN_ACCOUNT_PASSWORD + " PASSWORD " +
                ")";

        db.execSQL(create_table_cmd);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    public Cursor getData(){
        SQLiteDatabase db= this.getReadableDatabase();
        String query= "SELECT * FROM "+ TABLE_NAME;
        return db.rawQuery(query,null);

    }

    public void addAccount(Account account){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put(COLUMN_ACCOUNT_USERNAME, account.getName());
        values.put(COLUMN_ACCOUNT_PASSWORD,account.getPassword());

        db.insert(TABLE_NAME,null,values);
        db.close();



    }
}
