package com.example.admin_log;

public class Admin extends Account{

    public Admin(String name, String password) {
        super(name, password,"Admin");
    }

    public String getType() {
        return super.getType();
    }

    public void setType(String type) {
        super.setType(type);
    }
}
