package com.example.admin_log;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class InstructorSearchPage extends AppCompatActivity {

    Button searchcourseCode, searchcourseName;
    CourseDatabase coursedb;
    EditText txtcoursename,txtcoursecode;
    ListView courseList;
    ArrayList<String> courses;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_search);
        txtcoursename=findViewById(R.id.instructorcoursename);
        txtcoursecode=findViewById(R.id.instructorCourseCode);
        courseList=findViewById(R.id.searchList);
        searchcourseCode=findViewById(R.id.searchcode);
        searchcourseName=findViewById(R.id.searchname);
        courseList=findViewById(R.id.searchList);
        coursedb=new CourseDatabase(this);


        searchcourseCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                courses=new ArrayList<>();
                viewDataByCourseCode(coursedb,txtcoursecode.getText().toString());
            }
        });
        searchcourseName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                courses=new ArrayList<>();
                viewDataByCourseName(coursedb,txtcoursename.getText().toString());
            }
        });
    }
    private void viewDataByCourseName(CourseDatabase db,String name){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()){
                if(cursor.getString(0).equals(name)) {
                    courses.add("Course Name: " + cursor.getString(0) + "\nCourse Code: " + cursor.getString(1));
                }
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,courses);
        courseList.setAdapter(adapter);
    }
    private void viewDataByCourseCode(CourseDatabase db,String name){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()) {
                if (cursor.getString(1).equals(name)) {
                    courses.add("Course Name: " + cursor.getString(0) + "\nCourse Code: " + cursor.getString(1));
                }
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,courses);
        courseList.setAdapter(adapter);
    }
}
