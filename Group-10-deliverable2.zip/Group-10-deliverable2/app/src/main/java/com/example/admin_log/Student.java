package com.example.admin_log;

public class Student extends Account{


    public Student(String name, String password) {
        super(name, password,"Student");
    }
    public String getType() {
        return super.getType();
    }

    public void setType(String type) {
        super.setType(type);
    }

}
