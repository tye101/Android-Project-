package com.example.admin_log;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class CourseListPage extends AdminCoursePage{

    CourseDatabase coursedb;
    ListView courseList;
    ArrayList<String>courses;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_courses);
        courseList=findViewById(R.id.list_course);
        coursedb=new CourseDatabase(this);
        courses=new ArrayList<>();
        viewData(coursedb);







    }
    private void viewData(CourseDatabase db){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()){
                courses.add("Course Name: " + cursor.getString(0)+ "\nCourse Code: "+ cursor.getString(1));
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,courses);
        courseList.setAdapter(adapter);
    }

}
