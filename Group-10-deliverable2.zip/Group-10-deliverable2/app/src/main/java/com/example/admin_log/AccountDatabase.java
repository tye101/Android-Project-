package com.example.admin_log;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;

public class AccountDatabase extends SQLiteOpenHelper {
    private static final String TABLE_NAME="Account";
    private static final String COLUMN_ACCOUNT_USERNAME="username";
    private static final String COLUMN_ACCOUNT_PASSWORD="password";
    private static final String COLUMN_ACCOUNT_TYPE="position";
    private static final String DATABASE_NAME = "accounts.db";
    private static final int DATABASE_VERSION =1;


    public AccountDatabase(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String create= " CREATE TABLE " + TABLE_NAME +
                "(" + COLUMN_ACCOUNT_USERNAME + " TEXT PRIMARY KEY, "
                + COLUMN_ACCOUNT_PASSWORD + " TEXT, " +
                COLUMN_ACCOUNT_TYPE + " TEXT "+
                ")";

        db.execSQL(create);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    public Cursor getData(){
        SQLiteDatabase db= this.getReadableDatabase();
        String query= "SELECT * FROM "+ TABLE_NAME;
        return db.rawQuery(query,null);
    }
    public void deleteUser(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ACCOUNT_USERNAME + "=?", new String[]{name});
    }

    public void addAccount(Account account){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values= new ContentValues();
        values.put(COLUMN_ACCOUNT_USERNAME, account.getName());
        values.put(COLUMN_ACCOUNT_PASSWORD,account.getPassword());
        values.put(COLUMN_ACCOUNT_TYPE,account.getType());
        db.insert(TABLE_NAME,null,values);

    }
}
