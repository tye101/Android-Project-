package com.example.admin_log;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class InstructorAssignPage extends MainActivity {

    CourseDatabase db;
    Button editCourse,assignCourse, unassignCourse;
    EditText courseDescription,courseDays,courseHours,courseCapacity,courseName,instructorName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructor_assign);
        editCourse=findViewById(R.id.edit_course);
        assignCourse=findViewById(R.id.assign);
        unassignCourse=findViewById(R.id.unassign);
        courseCapacity=findViewById(R.id.course_capacity);
        courseDays=findViewById(R.id.course_days);
        courseDescription=findViewById(R.id.course_description);
        courseHours=findViewById(R.id.course_hours);
        courseName=findViewById(R.id.course_name);
        instructorName=findViewById(R.id.instructor_name);
        db=new CourseDatabase(this);

        assignCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String course_capacity=courseCapacity.getText().toString();
                String course_days=courseDays.getText().toString();
                String course_description=courseDescription.getText().toString();
                String course_hours=courseHours.getText().toString();
                String course_name=courseName.getText().toString();
                String instructor_name=instructorName.getText().toString();
                Course course=new Course();
                course.setCourseDays(course_days);
                course.setCourseHours(course_hours);
                course.setCourseCapacity(course_capacity);
                course.setCourseInstructor(instructor_name);
                course.setCourseDescription(course_description);
                course.setCourseName(course_name);
                Cursor cursor=db.getData();
                if (cursor.getCount() == 0) {
                    Toast.makeText(InstructorAssignPage.this, "No Courses in Database!", Toast.LENGTH_SHORT).show();
                } else {
                    while (cursor.moveToNext()) {
                        if (cursor.getString(0).equals(course_name) && cursor.getString(2)==null) {
                            db.updateCourse(course_name,course);
                            return;
                        }else if(cursor.getString(0).equals(course_name) && cursor.getString(2)!=null){
                            Toast.makeText(InstructorAssignPage.this, "This course is already Assigned Instructor "+ cursor.getString(2), Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    Toast.makeText(InstructorAssignPage.this, "This Course does not exist!", Toast.LENGTH_SHORT).show();
                }


            }
        });
        unassignCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String course_capacity=courseCapacity.getText().toString();
                String course_days=courseDays.getText().toString();
                String course_description=courseDescription.getText().toString();
                String course_hours=courseHours.getText().toString();
                String course_name=courseName.getText().toString();
                String instructor_name=instructorName.getText().toString();
                Cursor cursor=db.getData();
                Course course=new Course();
                course.setCourseDays(null);
                course.setCourseHours(null);
                course.setCourseCapacity(null);
                course.setCourseInstructor(null);
                course.setCourseDescription(null);
                if (cursor.getCount() == 0) {
                    Toast.makeText(InstructorAssignPage.this, "No Courses in Database!", Toast.LENGTH_SHORT).show();
                } else {
                    while (cursor.moveToNext()) {
                        if (cursor.getString(0).equals(course_name) && cursor.getString(2).equals(instructor_name)) {
                            db.updateCourse(course_name, course);
                            return;
                        }
                    }
                    Toast.makeText(InstructorAssignPage.this, "This Course does not exist!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        editCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String course_capacity=courseCapacity.getText().toString();
                String course_days=courseDays.getText().toString();
                String course_description=courseDescription.getText().toString();
                String course_hours=courseHours.getText().toString();
                String course_name=courseName.getText().toString();
                String instructor_name=instructorName.getText().toString();
                Cursor cursor=db.getData();
                Course course=new Course();
                course.setCourseDays(course_days);
                course.setCourseHours(course_hours);
                course.setCourseCapacity(course_capacity);
                course.setCourseInstructor(instructor_name);
                course.setCourseDescription(course_description);

                if (cursor.getCount() == 0) {
                    Toast.makeText(InstructorAssignPage.this, "No Courses in Database!", Toast.LENGTH_SHORT).show();
                } else {
                    while (cursor.moveToNext()) {
                        if (cursor.getString(0).equals(course_name) && cursor.getString(2).equals(instructor_name)) {
                            db.updateCourse(course_name,course);
                            return;
                        }else if((cursor.getString(0).equals(course_name) && !cursor.getString(2).equals(instructor_name))){
                            Toast.makeText(InstructorAssignPage.this, "This course is already Assigned Instructor "+ cursor.getString(2), Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    Toast.makeText(InstructorAssignPage.this, "This Course does not exist!", Toast.LENGTH_SHORT).show();
                }


            }
        });







    }
}
