package com.example.admin_log;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    EditText ID,Password;
    Button logIn,SignUp;
    AccountDatabase db;
    CourseDatabase cdb;
    CheckBox student,instructor;
    Instructor signedIn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ID=findViewById(R.id.user);
        student=findViewById(R.id.studentCheck);
        instructor=findViewById(R.id.instructorCheck);
        Password=findViewById(R.id.pass);
        logIn = findViewById(R.id.log);
        SignUp=findViewById(R.id.signup);
        db=new AccountDatabase(this);
        cdb=new CourseDatabase(this);

        SignUp.setOnClickListener(view -> {
            if(student.isChecked()){
                Student student= new Student(ID.getText().toString(),Password.getText().toString());
                db.addAccount(student);
            }else if(instructor.isChecked()){
                Instructor instructor= new Instructor(ID.getText().toString(),Password.getText().toString());
                db.addAccount(instructor);
            }
            ID.setText("");
            Password.setText("");
        });

        logIn.setOnClickListener(view -> {
            String username = ID.getText().toString();
            String password = Password.getText().toString();
            Cursor cursor = db.getData();
            if (cursor.getCount() == 0) {
                Toast.makeText(MainActivity.this, "No Accounts Registered!", Toast.LENGTH_SHORT).show();
            } else {
                while (cursor.moveToNext()) {
                    if (cursor.getString(0).equals(username) && cursor.getString(1).equals(password)) {
                        if (cursor.getString(2).equals("Admin")) {
                            Toast.makeText(MainActivity.this,"Welcome Admin: " + username,Toast.LENGTH_SHORT).show();
                            openAdminMenu();
                            return;
                        } else if (cursor.getString(2).equals("Instructor")) {
                            signedIn=new Instructor(username,password);
                            openInstructorMenu();
                            Toast.makeText(MainActivity.this,"Welcome Instructor: " + username,Toast.LENGTH_SHORT).show();
                            return;
                        } else if (cursor.getString(2).equals("Student")) {

                        }
                    }
                }
                Toast.makeText(MainActivity.this, "Error Logging In!", Toast.LENGTH_SHORT).show();

            }
        });

    }
    public void openAdminMenu(){
        Intent intent = new Intent(this, AdminMenuPage.class);
        startActivity(intent);
    }
    public void openInstructorMenu(){
        Intent intent = new Intent(this, InstructorMenuPage.class);
        startActivity(intent);
    }

}

