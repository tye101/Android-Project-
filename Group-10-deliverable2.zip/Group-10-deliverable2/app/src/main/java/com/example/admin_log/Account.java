package com.example.admin_log;

public class Account {
    private String name;
    private String password;
    private String type;

    public Account(String name, String password, String type) {
        this.name = name;
        this.password = password;
        this.type=type;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
