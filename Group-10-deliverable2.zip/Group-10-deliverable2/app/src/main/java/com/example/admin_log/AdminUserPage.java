package com.example.admin_log;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AdminUserPage extends AppCompatActivity {
    AccountDatabase db;
    Button search,delete,showall;
    ListView userList;
    ArrayList<String> users;
    ArrayAdapter adapter;
    EditText course_name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_users);
        userList=findViewById(R.id.user_list);
        search=findViewById(R.id.searchsearch);
        delete=findViewById(R.id.deleteduser);
        course_name=findViewById(R.id.user_name);
        showall=findViewById(R.id.showall);
        db=new AccountDatabase(this);


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                users=new ArrayList<>();
                viewDataByUserName(db,course_name.getText().toString());
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                users=new ArrayList<>();
                db.deleteUser(course_name.getText().toString());
                viewUsers(db);
            }
        });
        showall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                users=new ArrayList<>();
                viewUsers(db);
            }
        });
    }
    private void viewDataByUserName(AccountDatabase db,String name){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()) {
                if (cursor.getString(0).equals(name)) {
                    users.add("User Name: " + cursor.getString(0));
                }
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,users);
        userList.setAdapter(adapter);
    }
    private void viewUsers(AccountDatabase db){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()){
                users.add("User Name: " + cursor.getString(0));
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,users);
        userList.setAdapter(adapter);
    }
}
