package com.example.admin_log;

public class Instructor extends Account{

    public Instructor(String name, String password) {
        super(name, password,"Instructor");

    }
    public String getType() {
        return super.getType();
    }

    public void setType(String type) {
        super.setType(type);
    }
}
