package com.example.admin_log;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class StudentEnrollPage extends StudentMenuPage{
    Button enroll, unenroll;
    CourseDatabase coursedb;
    EditText txtcoursecode;
    ListView courseList;
    ArrayAdapter adapter;
    ArrayList<String> list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_enroll);
        txtcoursecode=findViewById(R.id.txtcoursecode);
        courseList=findViewById(R.id.searchListt);
        coursedb=new CourseDatabase(this);
        enroll=findViewById(R.id.enrol);
        unenroll=findViewById(R.id.unenroll);
        student=(Student) getIntent().getSerializableExtra("Student");
        list=new ArrayList<>();

        enroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enrollCourse(coursedb,txtcoursecode.getText().toString());

            }
        });
        unenroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                unenroll(txtcoursecode.getText().toString());

            }
        });
    }


    private void unenroll(String coursecode){
        for(int i=0;i<list.size();i++){
            if(list.get(i).contains(coursecode)){
                list.remove(i);
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,list);
        courseList.setAdapter(adapter);

    }
    private void enrollCourse(CourseDatabase db,String name) {
        Cursor cursor = db.getData();
        if (cursor.getCount() == 0) {
            return;
        } else {
            while (cursor.moveToNext()) {
                if (cursor.getString(1).equals(name)) {
                    for (int i = 0; i < list.size(); i++) {
                        if(list.get(i).contains(name)){
                            Toast.makeText(StudentEnrollPage.this, "This Course is already in your schedule", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (list.get(i).contains(cursor.getString(3)) && list.get(i).contains(cursor.getString(4))) {
                            Toast.makeText(StudentEnrollPage.this, "This Course Conflicts with another enrolled course!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    Course course = new Course();
                    course.setCourseName(cursor.getString(0));
                    course.setCourseID(cursor.getString(1));
                    course.setCourseDays(cursor.getString(3));
                    course.setCourseHours(cursor.getString(4));
                    course.setCourseDescription(cursor.getString(5));
                    course.setCourseCapacity(cursor.getString(6));
                    list.add(course.toString());
                }
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,list);
        courseList.setAdapter(adapter);


    }
}

