package com.example.admin_log;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
import java.util.HashMap;


public class CourseDatabase extends SQLiteOpenHelper {
    private static final String TABLE_NAME="Courses";
    private static final String COLUMN_ACCOUNT_COURSE_NAME="name";
    private static final String COLUMN_ACCOUNT_COURSE_CODE="code";
    private static final String COLUMN_ACCOUNT_COURSE_INSTRUCTOR="Instructor";
    private static final String COLUMN_ACCOUNT_COURSE_DAYS="days";
    private static final String COLUMN_ACCOUNT_COURSE_HOURS="hours";
    private static final String COLUMN_ACCOUNT_COURSE_DESCRIPTION="description";
    private static final String  COLUMN_ACCOUNT_COURSE_CAPACITY= "capacity";
    private static final String DATABASE_NAME = "courses.db";
    private static final int DATABASE_VERSION =1 ;

    public CourseDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        String create_table_cmd="CREATE TABLE " + TABLE_NAME +
                "(" + COLUMN_ACCOUNT_COURSE_NAME + " TEXT PRIMARY KEY, " +
                COLUMN_ACCOUNT_COURSE_CODE + " TEXT, " +
                COLUMN_ACCOUNT_COURSE_INSTRUCTOR + " TEXT, " +
                COLUMN_ACCOUNT_COURSE_DAYS + " TEXT, " +
                COLUMN_ACCOUNT_COURSE_HOURS + " TEXT, " +
                COLUMN_ACCOUNT_COURSE_DESCRIPTION + " TEXT, " +
                COLUMN_ACCOUNT_COURSE_CAPACITY + " TEXT "+
                ")";

        db.execSQL(create_table_cmd);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int i,int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    public void addCourse(Course course){
        SQLiteDatabase db =this.getReadableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(COLUMN_ACCOUNT_COURSE_NAME,course.getCourseName());
        cv.put(COLUMN_ACCOUNT_COURSE_CODE,course.getCourseID());
        cv.put(COLUMN_ACCOUNT_COURSE_INSTRUCTOR,course.getCourseInstructor());
        cv.put(COLUMN_ACCOUNT_COURSE_DAYS,course.getCourseDays());
        cv.put(COLUMN_ACCOUNT_COURSE_HOURS,course.getCourseHours());
        cv.put(COLUMN_ACCOUNT_COURSE_DESCRIPTION,course.getCourseDescription());
        cv.put(COLUMN_ACCOUNT_COURSE_CAPACITY,course.getCourseCapacity());


        db.insert(TABLE_NAME,null,cv);
    }
    public Cursor getData(){
        SQLiteDatabase db= this.getReadableDatabase();
        String query= "SELECT * FROM "+ TABLE_NAME;
        return db.rawQuery(query,null);
    }
    public void deleteTitle(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ACCOUNT_COURSE_NAME + "=?", new String[]{name});
    }
    public void updateCourse(String courseName,Course course2){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(COLUMN_ACCOUNT_COURSE_INSTRUCTOR, course2.getCourseInstructor());
        values.put(COLUMN_ACCOUNT_COURSE_DAYS, course2.getCourseDays());
        values.put(COLUMN_ACCOUNT_COURSE_HOURS, course2.getCourseHours());
        values.put(COLUMN_ACCOUNT_COURSE_DESCRIPTION, course2.getCourseDescription());
        values.put(COLUMN_ACCOUNT_COURSE_CAPACITY, course2.getCourseCapacity());


        // on below line we are calling a update method to update our database and passing our values.
        // and we are comparing it with name of our course which is stored in original name variable.
        db.update(TABLE_NAME, values, "name=?", new String[]{courseName});
    }




}

