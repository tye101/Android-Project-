package com.example.admin_log;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class InstructorMenuPage extends MainActivity {
        Button courseView,assignCourse, searchCourse;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_instructor_menu);
            courseView=findViewById(R.id.view_course);
            assignCourse=findViewById(R.id.assign_course);
            searchCourse=findViewById(R.id.searchcourse);

            courseView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openCourseList();
                }
            });
            searchCourse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openSearchPage();
                }
            });
            assignCourse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openAssignPage();
                }
            });

        }
    private void openCourseList(){
        Intent intent = new Intent(this, CourseListPage.class);
        startActivity(intent);
    }
    private void openSearchPage(){
        Intent intent = new Intent(this, InstructorSearchPage.class);
        startActivity(intent);
    }
    private void openAssignPage(){
        Intent intent = new Intent(this, InstructorAssignPage.class);
        startActivity(intent);
    }
}
