package com.example.admin_log;

import java.util.ArrayList;

public class Student extends Account{
    private ArrayList<Course> enrolledCourses;



    public Student(String name, String password) {
        super(name, password,"Student");
        this.enrolledCourses=new ArrayList<>();
    }
    public String getType() {
        return super.getType();
    }

    public void setType(String type) {
        super.setType(type);
    }

    public Course getCourse(String courseName){
        for(int i =0;i<enrolledCourses.size();i++){
            if(enrolledCourses.get(i).getCourseName().equals(courseName)){
                return enrolledCourses.get(i);
            }
        }
        return null;
    }
    public void enrolCourse(Course course){
        if(enrolledCourses.size()==0){
            return;
        }
        for(int i=0;i<enrolledCourses.size();i++){
            if(enrolledCourses.get(i).getCourseID().equals(course.getCourseID())){
                System.out.println("This course already exists in the database");
                return;
            }
        }
        enrolledCourses.add(course);
    }
    public void removeCourse(String courseName){
        for(int i =0;i<enrolledCourses.size();i++){
            if(enrolledCourses.get(i).getCourseID().equals(courseName)){
                enrolledCourses.remove(i);
            }
        }
    }

    public ArrayList<Course> getEnrolledCourses() {
        return enrolledCourses;
    }
}
