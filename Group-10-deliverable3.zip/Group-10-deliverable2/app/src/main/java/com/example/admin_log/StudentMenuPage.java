package com.example.admin_log;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.Serializable;

public class StudentMenuPage  extends MainActivity {
    Button edit,search;
    Account student;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_menu);
        student=(Student)getIntent().getSerializableExtra("Student");
        System.out.println(student);
        edit=findViewById(R.id.edit_your_courses);
        search=findViewById(R.id.seach_courses);

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openEnrolActivity();


            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSearchActivity();

            }
        });



    }
    private void openEnrolActivity(){
        Intent intent = new Intent(this, StudentEnrollPage.class);
        startActivity(intent);

    }
    private void openSearchActivity(){
        Intent intent = new Intent(this, StudentSearchPage.class);
        startActivity(intent);

    }


}
