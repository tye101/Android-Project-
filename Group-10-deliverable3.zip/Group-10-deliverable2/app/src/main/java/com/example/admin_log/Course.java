package com.example.admin_log;

public class Course {
    private String courseName;
    private String courseID;
    private String courseDescription;
    private String courseHours;
    private String courseDays;
    private String courseInstructor;
    private String courseCapacity;

    public Course(String courseName, String courseID) {
        this.courseName = courseName;
        this.courseID = courseID;
    }

    public Course() {
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public String getCourseHours() {
        return courseHours;
    }

    public void setCourseHours(String courseHours) {
        this.courseHours = courseHours;
    }

    public String getCourseDays() {
        return courseDays;
    }

    public void setCourseDays(String courseDays) {
        this.courseDays = courseDays;
    }

    public String getCourseCapacity() {
        return courseCapacity;
    }

    public void setCourseCapacity(String courseCapacity) {
        this.courseCapacity = courseCapacity;
    }

    public String getCourseInstructor() {
        return courseInstructor;
    }

    public void setCourseInstructor(String instructor) {
        courseInstructor = instructor;
    }
    public String toString(){
        return "Course Name: " + this.courseName +
                "\nCourse Code: " + this.courseID +
                "\nCourse Days: " + this.courseDays +
                "\nCourse Hours: " + this.courseHours;




    }
}
