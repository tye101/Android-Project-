package com.example.admin_log;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminCoursePage extends AppCompatActivity {
    EditText createCourseName,createCourseCode,editOldName,editOldCode,editNewName,editNewCode,deleteCourseName;
    Button b1,b2,b3,view_courses;
    CourseDatabase cdb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_courses);
        cdb=new CourseDatabase(AdminCoursePage.this);
        createCourseName=findViewById(R.id.editTextTextPassword14);
        createCourseCode=findViewById(R.id.editTextTextPassword15);
        editOldName=findViewById(R.id.editTextTextPassword6);
        editOldCode=findViewById(R.id.editTextTextPassword10);
        editNewName=findViewById(R.id.editTextTextPassword11);
        editNewCode=findViewById(R.id.editTextTextPassword12);
        deleteCourseName=findViewById(R.id.editTextTextPassword13);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        view_courses=findViewById(R.id.view);

        view_courses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCourseList();
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                cdb.addCourse(new Course(createCourseName.getText().toString(),createCourseCode.getText().toString()));
                createCourseCode.setText("");
                createCourseName.setText("");
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    cdb.updateCourse(editOldName.getText().toString(), new Course(editNewName.getText().toString(), editNewCode.getText().toString()));
                    editOldName.setText("");
                    editOldCode.setText("");
                    editNewName.setText("");
                    editNewCode.setText("");
                }catch (Exception e){
                    Toast.makeText(AdminCoursePage.this,e.toString(),Toast.LENGTH_SHORT).show();
                }

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cdb.deleteTitle(deleteCourseName.getText().toString());
                deleteCourseName.setText("");
            }
        });

    }
    private void openCourseList(){
        Intent intent = new Intent(this, CourseListPage.class);
        startActivity(intent);
    }

}