package com.example.admin_log;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;



import java.util.ArrayList;

public class StudentSearchPage extends StudentMenuPage {
    Button searchcourseCode, searchcourseName,searchcourseDay;
    CourseDatabase coursedb;
    EditText txtcoursename,txtcoursecode,txtcourseday;
    ListView courseList;
    ArrayList<String> courses;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_search);
        txtcoursename=findViewById(R.id.txtcoursename);
        txtcoursecode=findViewById(R.id.txtcoursecode);
        txtcourseday=findViewById(R.id.txtcourseday);
        searchcourseCode=findViewById(R.id.enrol);
        searchcourseName=findViewById(R.id.unenroll);
        searchcourseDay=findViewById(R.id.searchcourseday);
        courseList=findViewById(R.id.searchListt);
        coursedb=new CourseDatabase(this);


        searchcourseCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                courses=new ArrayList<>();
                viewDataByCourseCode(coursedb,txtcoursecode.getText().toString());
            }
        });
        searchcourseName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                courses=new ArrayList<>();
                viewDataByCourseName(coursedb,txtcoursename.getText().toString());
            }
        });
        searchcourseDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                courses=new ArrayList<>();
                viewDataByCourseDay(coursedb,txtcourseday.getText().toString());
            }
        });
    }
    private void viewDataByCourseName(CourseDatabase db,String name){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()){
                if(cursor.getString(0).equals(name)) {
                    courses.add("Course Name: " + cursor.getString(0) + "\nCourse Code: " + cursor.getString(1));
                }
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,courses);
        courseList.setAdapter(adapter);
    }
    private void viewDataByCourseCode(CourseDatabase db,String name){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()) {
                if (cursor.getString(1).equals(name)) {
                    courses.add("Course Name: " + cursor.getString(0) + "\nCourse Code: " + cursor.getString(1));
                }
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,courses);
        courseList.setAdapter(adapter);
    }
    private void viewDataByCourseDay(CourseDatabase db,String courseDay){
        Cursor cursor=db.getData();
        if(cursor.getCount()==0){
            return;
        }else{
            while(cursor.moveToNext()) {
                if(cursor.getString(3)==null){
                    continue;
                }
                if (cursor.getString(3).contains(courseDay)) {
                    courses.add("Course Name: " + cursor.getString(0) + "\nCourse Code: " + cursor.getString(1) + "\nCourse Days: " + cursor.getString(3));

                }
            }
        }
        adapter= new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1,courses);
        courseList.setAdapter(adapter);

    }
}

